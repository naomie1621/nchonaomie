<h1>Gestion des utilisateurs</h1>
<br>
<a href="/AppMvc/tasks/create/" class="btn btn-primary btn-xs pull-right">
        <b>+</b>Ajouter un nouveau utilisateur</a>
        <br><br><br>
<div class="row col-md-12 centered">
    <table class="table table-striped custab">
        <thead>
        
        
        <tr>
            <th>Matricule</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th class="text-center">Action</th>
        </tr>
        </thead>
        <?php
    

        foreach ($tasks as $task)
        {
            echo '<tr>';
            echo "<td>" . $task['Id'] . "</td>";
            echo "<td>" . $task['Nom'] . "</td>";
            echo "<td>" . $task['Prénom'] . "</td>";
            echo "<td>" . $task['Email'] . "</td>";
            echo "<td>" . $task['Téléphone'] . "</td>";
            echo "<td class='text-center'><a class='btn btn-info btn-xs' href='/AppMvc/tasks/edit/" . $task["Id"] . "' >
            <span class='glyphicon glyphicon-edit'></span> Edit</a> <a href='/AppMvc/tasks/delete/" . $task["Id"] . 
            "' class='btn btn-danger btn-xs'><span class='glyphicon glyphicon-remove'></span> Del</a></td>";
            echo "</tr>";
        }
        ?>
    </table>
</div>