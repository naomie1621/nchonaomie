<h1>Créer utilisateur</h1>
<form method='post' action='#'>
    <div class="form-group">
        <label for="title">Nom</label>
        <input type="text" class="form-control" id="Nom" placeholder="Entrer le Nom" name="Nom">
    </div>

    <div class="form-group">
        <label for="description">Prénom</label>
        <input type="text" class="form-control" id="Prénom" placeholder="Entrer le Prénom" name="Prénom">
    </div>

    <div class="form-group">
        <label for="description">Email</label>
        <input type="text" class="form-control" id="Email" placeholder="Entrer l'Email" name="Email">
    </div>

    <div class="form-group">
        <label for="description">Téléphone</label>
        <input type="text" class="form-control" id="Téléphone" placeholder="Entrer le Téléphone" name="Téléphone">
    </div>

    <div class="form-group">
        <label for="description">Mot de pass</label>
        <input type="text" class="form-control" id="Password" placeholder="Entrer un Mot de pass" name="Password">
    </div>

    <div class="form-group">
        <label for="description">Confirmation</label>
        <input type="text" class="form-control" id="Confirmation" placeholder="Confirmer le mot de pass" name="Confirmation">
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>