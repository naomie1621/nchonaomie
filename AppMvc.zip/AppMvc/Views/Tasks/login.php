
<!-- This snippet uses Font Awesome 5 Free as a dependency. You can download it at fontawesome.io! -->

<body>
  <div class="container">
    <div class="row">
      <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
        <div class="card card-signin my-5">
          <div class="card-body">
            <h5 class="card-title text-center">Log in</h5>
            <form class="form-signin">
              <div class="form-label-group">
                <input type="text" id="Nom" class="form-control" placeholder="Nom d'utilisateur" Name="Nom" required autofocus>
                <label for="inputEmail">Utilisateur</label>
              </div>

              <div class="form-label-group">
                <input type="password" id="Password" class="form-control" placeholder="Mot de pass" Name="Password" required>
                <label for="inputPassword">Mot de pass</label>
              </div>

              <button class="btn btn-lg btn-primary btn-block text-uppercase" type="submit">Connexion</button>
              <hr class="my-4">

            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>