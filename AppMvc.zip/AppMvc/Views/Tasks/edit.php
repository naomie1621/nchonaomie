<h1>Editer utilisateur</h1>
<form method='post' action='#'>
    <div class="form-group">
        <label for="title">Nom</label>
        <input type="text" class="form-control" id="Nom" placeholder="Entrer le Nom" name="Nom" value ="<?php if (isset($task["Nom"])) echo $task["Nom"];?>">
    </div>

    <div class="form-group">
        <label for="description">Prénom</label>
        <input type="text" class="form-control" id="Prénom" placeholder="Entrer le Prénom" name="Prénom" value ="<?php if (isset($task["Prénom"])) echo $task["Prénom"];?>">
    </div>

    <div class="form-group">
        <label for="description">Email</label>
        <input type="text" class="form-control" id="Email" placeholder="Entrer l'Email" name="Email" value ="<?php if (isset($task["Email"])) echo $task["Email"];?>">
    </div>

    <div class="form-group">
        <label for="description">Téléphone</label>
        <input type="text" class="form-control" id="Téléphone" placeholder="Entrer le Téléphone" name="Téléphone" value ="<?php if (isset($task["Téléphone"])) echo $task["Téléphone"];?>">
    </div>
    <button type="submit" class="btn btn-primary">Valider</button>
</form>