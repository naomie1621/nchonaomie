<?php
class tasksController extends Controller
{
    function index()
    {
        require(ROOT . 'Models/Task.php');

        $tasks = new Task();
        $d['tasks'] = $tasks->showAllUsers();
        $this->set($d);
        $this->render("index");
    }

    function create()
    {
        if (isset($_POST["Nom"]))
        {
            require(ROOT . 'Models/Task.php');

            $task= new Task();
            if ($task->create($_POST["Nom"], $_POST["Prénom"], $_POST["Email"], $_POST["Téléphone"], $_POST["Password"]))
            {
                header("Location: " . WEBROOT . "intervention/index");
            }
        }

        $this->render("create");
    }

    function edit($Id)
    {
        require(ROOT . 'Models/Task.php');
        $task= new Task();

        $d["task"] = $task->showUser($Id);

        if (isset($_POST["Nom"]))
        {
            if ($task->edit($Id, $_POST["Nom"], $_POST["Prénom"], $_POST["Email"], $_POST["Téléphone"]))
            {
                header("Location: " . WEBROOT . "tasks/index");
            }
        }
        $this->set($d);
        $this->render("edit");
    }

    function delete($Id)
    {
        require(ROOT . 'Models/Task.php');

        $task = new Task();
        if ($task->delete($Id))
        {
            
            header("Location: " . WEBROOT . "tasks/index");
        }
    }
    function login()
    {
        if (isset($_POST["Nom"]))
        {
             require(ROOT . 'Models/Task.php');

             $task= new Task();
             if ($task->login($_POST["Nom"],$_POST["Password"]))
             {
                header("Location: " . WEBROOT . "tasks/index");
             }
        }

        $this->render("login");
    }
}
?>