<?php
class Task extends Model
{
    public function create($Nom, $Prénom,$Email,$Téléphone,$Password)
    {//INSERT INTO `pompier` (`Id`, `Nom`, `Prenom`, `Email`, `Tel`, `Password`) 
     //VALUES (NULL, 'Larzak', 'Amal', 'amal.larzak@gmail.com', '062254122', '123');
        $sql = "INSERT INTO `pompier` (`Nom`, `Prénom`, `Email`, `Téléphone`, `Password`) 
        VALUES ('$Nom', '$Prénom', '$Email', '$Téléphone', md5('$Password'))";

        $req = Database::getBdd()->prepare($sql);
        return $req->execute();
    }

    public function showUser($Id)
    {
        $sql = "SELECT * FROM pompier WHERE Id =" . $Id;
        $req = Database::getBdd()->prepare($sql);
        $req->execute();
        return $req->fetch();
    }

    public function showAllUsers()
    {
        $sql = "SELECT * FROM pompier";
        $req = Database::getBdd()->prepare($sql);
        $req->execute();
        return $req->fetchAll();
    }

    public function edit($Id, $Nom, $Prénom,$Email,$Téléphone)
    {
        $sql = "UPDATE pompier SET Nom = '$Nom', Prénom = '$Prénom' , Email = '$Email' , Téléphone = '$Téléphone' WHERE Id = $Id";

        $req = Database::getBdd()->prepare($sql);

        return $req->execute();
    }

    public function delete($Id)
    {
        $sql = "DELETE FROM pompier WHERE Id = $Id";
        $req = Database::getBdd()->prepare($sql);
        return $req->execute();
    }

    public function login($Nom,$Password)
    {
        $sql = "SELECT * FROM pompier WHERE username=$Nom AND password=$Password";
        $req = Database::getBdd()->prepare($sql);
        return $req->execute();
    }
}
?>