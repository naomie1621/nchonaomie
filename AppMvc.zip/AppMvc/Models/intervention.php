<?php
class Intervention extends Model
{
    public function create($NomIntervention, $Statut,$DateD,$HeureD,$DateF,$HeureF)
    {
        $sql = "INSERT INTO `intervention` (`NomIntervention`, `Statut`,`DateD`,`HeureD`,`DateF`,`HeureF`) 
        VALUES ('$NomIntervention', '$Statut', '$DateD', '$HeureD', '$DateF','$HeureF')";

        $req = Database::getBdd()->prepare($sql);
        return $req->execute();
    }

    public function showInterv($Id)
    {
        //echo $Id;
        $sql = "SELECT * FROM intervention WHERE IdInterv =" . $Id;
        $req = Database::getBdd()->prepare($sql);
        $req->execute();
        //echo $req->fetch();
        return $req->fetch();
    }

    public function showAllInterv()
    {
        $sql = "SELECT * FROM intervention";
        $req = Database::getBdd()->prepare($sql);
        $req->execute();
        return $req->fetchAll();
    }

    public function edit($Id,$NomIntervention, $Statut,$DateD,$HeureD,$DateF,$HeureF)
    {
        $sql = "UPDATE intervention SET NomIntervention = '$NomIntervention', Statut = '$Statut' ,
         DateD = '$DateD' , HeureD = '$HeureD', DateF = '$DateF',HeureF = '$HeureF' WHERE IdInterv = $Id";

        $req = Database::getBdd()->prepare($sql);

        return $req->execute();
    }

    public function delete($Id)
    {
        $sql = "DELETE FROM intervention WHERE IdInterv = $Id";
        $req = Database::getBdd()->prepare($sql);
        return $req->execute();
    }

}
?>