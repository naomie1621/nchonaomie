<main role="main" class="container">
    <div class="starter-template">
    <h1>Page d'accueil par défaut</h1>
    <p class="lead">Bienvenue sur ma super page.</p>
    </div>
</main><!-- /.container -->
