<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">

<title>UHA - archiweb - tds</title>

<!-- Bootstrap core CSS -->
<link href="./vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome Icons Free 5.12.1 CSS -->
  <link href="./vendors/fontawesome/css/fontawesome.min.css" rel="stylesheet">
  <link href="./vendors/fontawesome/css/brands.min.css" rel="stylesheet">
  <link href="./vendors/fontawesome/css/solid.min.css" rel="stylesheet">